# Rutina Tracker App

Esta es una aplicación simple para llevar el control de tus entrenamientos semanales.

## Cómo usarla

1. Ve a https://vercel.com
2. Crea una cuenta y sube este proyecto como una nueva app
3. O instala Node.js y corre:

```bash
npm install
npm run dev
```

Abre http://localhost:3000 para ver la app